## GG well trade! (BETA)

...allows you to find trades from the most used Rocket League trades platforms.

#How to

To perform a new search please follow these easy steps: 

1. Put in the [H]ave panel the item you WANT 
2. Put in the [W]ant panel the item you HAVE 
3. To run press the Start button 
4. Press the Stop button to cancel the current search 
5. Double-click on a trade to open it

###### Remember that you don't need to Start Stop the current search to find new trades, they will be added to the list automatically.

If new items are added to the game please use the "Update items" function under the Menu and expect a new update.
For newer versions please refer to this page or to my profiles.

If you like my work, please donate, I really appreciated any type of donations :)

[![Paypal](https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=QH56EW28TJGEY)

*Donators*

-------------
**ENJOY!**

#Terms and conditions

This application is published under the MIT License, modified version of the original work must contains original author's references.
By downloading, copying or using the Software, You agree to the terms and conditions of this Agreement.

*Softwares under [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) were used for the project.*


*Copyright (c) Antonio Santoro - 2016*
